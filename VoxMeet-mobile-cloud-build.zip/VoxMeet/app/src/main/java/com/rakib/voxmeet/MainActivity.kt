package com.rakib.voxmeet

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF10142B)
private val Panel = Color(0xFF1B2140)
private val Purple = Color(0xFF8B7CFF)
private val Mint = Color(0xFF54E0C1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VoxMeetApp() }
    }
}

data class VoiceRoom(val title: String, val topic: String, val people: Int, val host: String, val tag: String)

@Composable
fun VoxMeetApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var activeRoom by remember { mutableStateOf<VoiceRoom?>(null) }
    var micOn by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    val rooms = remember {
        mutableStateListOf(
            VoiceRoom("আজকের আড্ডা", "নতুন বন্ধু • গল্প • পরিচয়", 18, "Rakib", "বাংলা"),
            VoiceRoom("গান ও কবিতা", "গান, কবিতা এবং ভালো লাগা", 12, "Sami", "Music"),
            VoiceRoom("প্রবাস জীবনের গল্প", "সৌদি আরব ও প্রবাসের অভিজ্ঞতা", 26, "Nayeem", "Community"),
            VoiceRoom(" রাত জাগা বন্ধুরা", "চলো একটু কথা বলি", 7, "Arif", "Chill")
        )
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (activeRoom != null) {
                RoomScreen(room = activeRoom!!, micOn = micOn, onMic = { micOn = !micOn }, onLeave = { activeRoom = null; micOn = false })
            } else {
                Scaffold(
                    containerColor = Navy,
                    floatingActionButton = {
                        FloatingActionButton(onClick = { showCreate = true }, containerColor = Purple, contentColor = Color.White) {
                            Icon(Icons.Default.Add, contentDescription = "Create room")
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Panel, contentColor = Color.White) {
                            NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                            NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.People, null) }, label = { Text("Friends") })
                            NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
                        }
                    }
                ) { padding ->
                    if (selectedTab == 0) HomeScreen(rooms, Modifier.padding(padding), onJoin = { activeRoom = it })
                    else SimpleTab(if (selectedTab == 1) "বন্ধুরা" else "আমার প্রোফাইল", Modifier.padding(padding))
                }
                if (showCreate) CreateRoomDialog(onDismiss = { showCreate = false }, onCreate = { name ->
                    val room = VoiceRoom(name, "নতুন একটি আড্ডার ঘর", 1, "Rakib", "New")
                    rooms.add(0, room); showCreate = false; activeRoom = room
                })
            }
        }
    }
}

@Composable
fun HomeScreen(rooms: List<VoiceRoom>, modifier: Modifier = Modifier, onJoin: (VoiceRoom) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 28.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("VOXMEET", color = Mint, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("তোমার আড্ডা,\nতোমার মানুষ।", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 35.sp)
                }
                Box(Modifier.size(52.dp).background(Brush.linearGradient(listOf(Purple, Mint)), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Headphones, null, tint = Navy, modifier = Modifier.size(29.dp))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LIVE VOICE COMMUNITY", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("কথা বলো, নতুন বন্ধু বানাও", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("পছন্দের রুমে যোগ দাও এবং সবার সঙ্গে আড্ডা দাও।", color = Color.LightGray, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(Mint, CircleShape)); Spacer(Modifier.width(7.dp)); Text("${rooms.sumOf { it.people }} জন রুমে আছে", color = Mint, fontSize = 12.sp)
                    }
                }
            }
        }
        item { Text("জনপ্রিয় ভয়েস রুম", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(rooms) { room -> RoomCard(room, onClick = { onJoin(room) }) }
        item { Text("VoxMeet • Connect through conversations", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
    }
}

@Composable
fun RoomCard(room: VoiceRoom, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF30365D), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Headphones, null, tint = Mint) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text(room.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("হোস্ট: ${room.host}", color = Color.LightGray, fontSize = 12.sp) }
                Text("● LIVE", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Text(room.topic, color = Color.LightGray, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${room.people} জন শুনছেন", color = Color.Gray, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("Join room  →", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RoomScreen(room: VoiceRoom, micOn: Boolean, onMic: () -> Unit, onLeave: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("←  রুম ছেড়ে যান", color = Color.LightGray, modifier = Modifier.clickable { onLeave() })
            Text("● LIVE", color = Mint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(52.dp))
        Text(room.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text(room.topic, color = Color.LightGray, fontSize = 13.sp)
        Spacer(Modifier.height(42.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Avatar("R", "Rakib", true); Avatar("S", "Sami", false); Avatar("A", "Arif", false)
        }
        Spacer(Modifier.height(30.dp))
        Text("${room.people} জন রুমে আছেন", color = Mint, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        Text(if (micOn) "তোমার মাইক্রোফোন UI-তে চালু" else "তুমি এখন শ্রোতা হিসেবে আছো", color = Color.LightGray, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onMic, colors = ButtonDefaults.buttonColors(containerColor = if (micOn) Mint else Purple), shape = CircleShape, modifier = Modifier.size(76.dp)) {
            Icon(if (micOn) Icons.Default.Mic else Icons.Default.MicOff, contentDescription = "Toggle microphone", tint = Navy, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(10.dp)); Text(if (micOn) "মাইক বন্ধ করো" else "মাইক চালু করো", color = Color.White, fontSize = 12.sp)
        Spacer(Modifier.height(30.dp))
        OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF7777))) { Text("Leave room") }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
fun Avatar(initial: String, name: String, speaking: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(68.dp).background(if (speaking) Purple else Color(0xFF30365D), CircleShape), contentAlignment = Alignment.Center) { Text(initial, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(7.dp)); Text(name, color = Color.White, fontSize = 12.sp)
        if (speaking) Text("Host", color = Mint, fontSize = 10.sp)
    }
}

@Composable
fun CreateRoomDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("নতুন ভয়েস রুম", color = Color.White) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("রুমের নাম") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }) { Text("তৈরি করো") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}

@Composable
fun SimpleTab(title: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("$title\nশীঘ্রই আসছে", color = Color.White, fontSize = 22.sp, lineHeight = 32.sp) }
}
