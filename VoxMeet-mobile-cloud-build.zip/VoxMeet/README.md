# VoxMeet Android starter

A Kotlin + Jetpack Compose Android starter for a Bengali-first voice-room community app.

## Included in this first source-code milestone
- Home screen with sample public rooms
- Create-room dialog (local/demo state only)
- Room screen and microphone UI toggle
- Home / Friends / Profile navigation shell
- Android internet and microphone permissions declared

## Important: live voice is not connected yet
The current project is a UI prototype. The room list and microphone toggle are local demo behavior; they do not connect people over the internet and do not transmit audio. A real multi-user voice app needs an RTC provider/server (for example, a self-hosted LiveKit deployment or a provider account), authenticated room tokens, backend APIs, user accounts, moderation/reporting, and privacy/security work. Never put an RTC secret/API secret in the Android app.

## Build
1. Install Android Studio (latest stable) and Android SDK Platform 35.
2. Open this `VoxMeet` folder in Android Studio.
3. Allow Gradle sync; use JDK 17.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Application ID: `com.rakib.voxmeet`
Version: `1.0.0` (starter)
Minimum Android: 7.0 (API 24)
