# VoxMeet Android starter — profile/avatar update

This source includes:
- Home, demo room and profile navigation
- Profile photo selection from the device using Android's document picker
- Photo URI persistence on the same device
- Selectable animated, 3D-styled illustrated human avatars (male/female variants)
- Updated GitHub Actions workflow with the correct `VoxMeet/` working directory

## Important limitations
This source archive does not include Firebase configuration (`google-services.json`), Firebase Storage/Firestore setup, a backend, or 3D model (`.glb`) assets. Therefore profile photos and avatar choices are currently stored locally on the device; they are not synced to Firebase or across devices. The avatar artwork is a Compose-drawn animated illustration, not a fully rendered 3D model. A true 3D character requires approved 3D model assets and a 3D rendering integration.

The voice-room and microphone controls remain demo UI only and do not transmit audio.

## Build
Open the `VoxMeet` folder in Android Studio with JDK 17 and Android SDK 35, sync Gradle, then build the debug APK.
