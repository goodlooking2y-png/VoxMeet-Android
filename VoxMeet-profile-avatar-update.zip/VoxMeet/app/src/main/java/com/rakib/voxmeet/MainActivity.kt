package com.rakib.voxmeet

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Navy = Color(0xFF10142B)
private val Panel = Color(0xFF1B2140)
private val Purple = Color(0xFF8B7CFF)
private val Mint = Color(0xFF54E0C1)
private val Pink = Color(0xFFFF63B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VoxMeetApp() }
    }
}

data class VoiceRoom(val title: String, val topic: String, val people: Int, val host: String, val tag: String)

@Composable
fun VoxMeetApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("voxmeet_profile", Context.MODE_PRIVATE) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var activeRoom by remember { mutableStateOf<VoiceRoom?>(null) }
    var micOn by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var showAvatarPicker by remember { mutableStateOf(false) }
    var photoUri by remember { mutableStateOf(prefs.getString("photo_uri", null)) }
    var selectedAvatar by remember { mutableIntStateOf(prefs.getInt("avatar_id", 0)) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            photoUri = uri.toString()
            prefs.edit().putString("photo_uri", photoUri).apply()
        }
    }

    val rooms = remember {
        mutableStateListOf(
            VoiceRoom("আজকের আড্ডা", "নতুন বন্ধু • গল্প • পরিচয়", 18, "Rakib", "বাংলা"),
            VoiceRoom("গান ও কবিতা", "গান, কবিতা এবং ভালো লাগা", 12, "Sami", "Music"),
            VoiceRoom("প্রবাস জীবনের গল্প", "সৌদি আরব ও প্রবাসের অভিজ্ঞতা", 26, "Nayeem", "Community"),
            VoiceRoom("রাত জাগা বন্ধুরা", "চলো একটু কথা বলি", 7, "Arif", "Chill")
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (activeRoom != null) {
                RoomScreen(room = activeRoom!!, micOn = micOn, onMic = { micOn = !micOn }, onLeave = { activeRoom = null; micOn = false })
            } else {
                Scaffold(
                    containerColor = Navy,
                    floatingActionButton = {
                        if (selectedTab == 0) FloatingActionButton(onClick = { showCreate = true }, containerColor = Purple, contentColor = Color.White) {
                            Icon(Icons.Default.Add, contentDescription = "Create room")
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Panel, contentColor = Color.White) {
                            NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                            NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.People, null) }, label = { Text("Friends") })
                            NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
                        }
                    }
                ) { padding ->
                    when (selectedTab) {
                        0 -> HomeScreen(rooms, Modifier.padding(padding), onJoin = { activeRoom = it })
                        1 -> SimpleTab("বন্ধুরা", Modifier.padding(padding))
                        else -> ProfileScreen(
                            modifier = Modifier.padding(padding),
                            photoUri = photoUri,
                            selectedAvatar = selectedAvatar,
                            onChoosePhoto = { photoPicker.launch(arrayOf("image/*")) },
                            onChooseAvatar = { showAvatarPicker = true }
                        )
                    }
                }
                if (showCreate) CreateRoomDialog(onDismiss = { showCreate = false }, onCreate = { name ->
                    val room = VoiceRoom(name, "নতুন একটি আড্ডার ঘর", 1, "Rakib", "New")
                    rooms.add(0, room); showCreate = false; activeRoom = room
                })
                if (showAvatarPicker) AvatarPickerDialog(
                    selectedAvatar = selectedAvatar,
                    onDismiss = { showAvatarPicker = false },
                    onSelect = { id ->
                        selectedAvatar = id
                        photoUri = null
                        prefs.edit().putInt("avatar_id", id).remove("photo_uri").apply()
                        showAvatarPicker = false
                    }
                )
            }
        }
    }
}

@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    photoUri: String?,
    selectedAvatar: Int,
    onChoosePhoto: () -> Unit,
    onChooseAvatar: () -> Unit
) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MY ACCOUNT", color = Pink, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("My Profile", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text("⚙", color = Color.White, fontSize = 25.sp)
        }
        Spacer(Modifier.height(22.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF35215B), Color(0xFF8A3C78)))).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(142.dp).shadow(10.dp, CircleShape).clip(CircleShape).background(Color(0xFF33204F)), contentAlignment = Alignment.Center) {
                    if (!photoUri.isNullOrBlank()) {
                        AsyncImage(model = Uri.parse(photoUri), contentDescription = "Profile photo", modifier = Modifier.fillMaxSize().clip(CircleShape))
                    } else {
                        HumanAvatar(avatarId = selectedAvatar, modifier = Modifier.fillMaxSize())
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onChoosePhoto, shape = RoundedCornerShape(30.dp)) {
                        Icon(Icons.Default.PhotoCamera, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp)); Text("ছবি বদলান")
                    }
                    OutlinedButton(onClick = onChooseAvatar, shape = RoundedCornerShape(30.dp)) {
                        Text("3D Avatar")
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("Rakib", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("VoxMeet community member", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                Text("VoxMeet ID: —", color = Mint, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(22.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("0", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Following", color = Color.LightGray, fontSize = 12.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("0", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Followers", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("প্রোফাইল ছবি ও Avatar", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(6.dp))
                Text("ফোনের গ্যালারি থেকে ছবি বেছে নিন অথবা নিচের 3D চরিত্রগুলোর একটি নির্বাচন করুন। আপনার পছন্দ এই ফোনে সংরক্ষিত থাকবে।", color = Color.LightGray, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
fun AvatarPickerDialog(selectedAvatar: Int, onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("আপনার 3D Avatar বেছে নিন", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("পছন্দের মানব চরিত্রে চাপ দিন।", color = Color.LightGray, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    (0..3).forEach { id ->
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (selectedAvatar == id) Color(0xFF3C3266) else Color(0xFF25213D)).clickable { onSelect(id) }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            HumanAvatar(id, Modifier.size(62.dp))
                            Text(if (id % 2 == 0) "ছেলে" else "মেয়ে", color = Color.White, fontSize = 10.sp)
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    (4..7).forEach { id ->
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (selectedAvatar == id) Color(0xFF3C3266) else Color(0xFF25213D)).clickable { onSelect(id) }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            HumanAvatar(id, Modifier.size(62.dp))
                            Text(if (id % 2 == 0) "ছেলে" else "মেয়ে", color = Color.White, fontSize = 10.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("বন্ধ") } }
    )
}

@Composable
fun HumanAvatar(avatarId: Int, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "avatarBob")
    val bob by transition.animateFloat(
        initialValue = -2.5f, targetValue = 2.5f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val female = avatarId % 2 == 1
    val skin = listOf(Color(0xFFB8754F), Color(0xFFD69A72), Color(0xFF9C5D42), Color(0xFFE0AA83))[avatarId % 4]
    val hair = listOf(Color(0xFF211A24), Color(0xFF35221D), Color(0xFF171923), Color(0xFF4B3026))[avatarId % 4]
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val shift = bob * density
        // shoulders and torso
        drawOval(Brush.linearGradient(listOf(Color(0xFF9A55D8), Color(0xFF35245D))), Offset(w * .12f, h * .67f + shift), Size(w * .76f, h * .52f))
        drawRoundRect(Brush.verticalGradient(listOf(skin.copy(alpha = .95f), skin)), Offset(cx - w*.09f, h*.55f + shift), Size(w*.18f, h*.18f), androidx.compose.ui.geometry.CornerRadius(w*.05f))
        // ears and face
        drawCircle(skin, w*.075f, Offset(cx - w*.245f, h*.39f + shift))
        drawCircle(skin, w*.075f, Offset(cx + w*.245f, h*.39f + shift))
        drawCircle(Brush.radialGradient(listOf(skin.copy(red = (skin.red + .12f).coerceAtMost(1f)), skin, skin.copy(red = (skin.red*.72f).coerceAtLeast(0f))), center = Offset(cx-w*.08f, h*.30f+shift), radius = w*.48f), w*.245f, Offset(cx, h*.38f+shift))
        // hair cap and side locks
        drawArc(hair, 180f, 180f, false, Offset(cx-w*.25f, h*.13f+shift), Size(w*.50f, h*.37f))
        if (female) {
            drawOval(hair, Offset(cx-w*.28f, h*.27f+shift), Size(w*.13f, h*.40f))
            drawOval(hair, Offset(cx+w*.15f, h*.27f+shift), Size(w*.13f, h*.40f))
        } else {
            drawOval(hair, Offset(cx-w*.245f, h*.22f+shift), Size(w*.49f, h*.13f))
        }
        // eyes, nose and smile
        drawCircle(Color(0xFF241B20), w*.018f, Offset(cx-w*.09f, h*.385f+shift))
        drawCircle(Color(0xFF241B20), w*.018f, Offset(cx+w*.09f, h*.385f+shift))
        drawCircle(Color.White, w*.007f, Offset(cx-w*.095f, h*.378f+shift))
        drawCircle(Color.White, w*.007f, Offset(cx+w*.085f, h*.378f+shift))
        drawLine(skin.copy(red = (skin.red*.72f).coerceAtLeast(0f)), Offset(cx, h*.40f+shift), Offset(cx-w*.018f, h*.46f+shift), strokeWidth = w*.012f)
        drawArc(Color(0xFF8D3945), 10f, 160f, false, Offset(cx-w*.065f, h*.455f+shift), Size(w*.13f, h*.07f), style = Stroke(width = w*.012f))
        if (female) {
            drawArc(Color(0xFFDB5C9C), 190f, 160f, false, Offset(cx-w*.26f, h*.14f+shift), Size(w*.52f, h*.40f), style = Stroke(width = w*.045f))
        }
    }
}

@Composable
fun HomeScreen(rooms: List<VoiceRoom>, modifier: Modifier = Modifier, onJoin: (VoiceRoom) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 28.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("VOXMEET", color = Mint, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("তোমার আড্ডা,\nতোমার মানুষ।", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 35.sp)
                }
                Box(Modifier.size(52.dp).background(Brush.linearGradient(listOf(Purple, Mint)), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Headphones, null, tint = Navy, modifier = Modifier.size(29.dp))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LIVE VOICE COMMUNITY", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("কথা বলো, নতুন বন্ধু বানাও", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("পছন্দের রুমে যোগ দাও এবং সবার সঙ্গে আড্ডা দাও।", color = Color.LightGray, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(Mint, CircleShape)); Spacer(Modifier.width(7.dp)); Text("${rooms.sumOf { it.people }} জন রুমে আছে", color = Mint, fontSize = 12.sp)
                    }
                }
            }
        }
        item { Text("জনপ্রিয় ভয়েস রুম", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(rooms) { room -> RoomCard(room, onClick = { onJoin(room) }) }
        item { Text("VoxMeet • Connect through conversations", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
    }
}

@Composable
fun RoomCard(room: VoiceRoom, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF30365D), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Headphones, null, tint = Mint) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text(room.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("হোস্ট: ${room.host}", color = Color.LightGray, fontSize = 12.sp) }
                Text("● LIVE", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Text(room.topic, color = Color.LightGray, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${room.people} জন শুনছেন", color = Color.Gray, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("Join room  →", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RoomScreen(room: VoiceRoom, micOn: Boolean, onMic: () -> Unit, onLeave: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("←  রুম ছেড়ে যান", color = Color.LightGray, modifier = Modifier.clickable { onLeave() })
            Text("● LIVE", color = Mint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(52.dp))
        Text(room.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Text(room.topic, color = Color.LightGray, fontSize = 13.sp)
        Spacer(Modifier.height(42.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Avatar("R", "Rakib", true); Avatar("S", "Sami", false); Avatar("A", "Arif", false)
        }
        Spacer(Modifier.height(30.dp))
        Text("${room.people} জন রুমে আছেন", color = Mint, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        Text(if (micOn) "তোমার মাইক্রোফোন UI-তে চালু" else "তুমি এখন শ্রোতা হিসেবে আছো", color = Color.LightGray, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onMic, colors = ButtonDefaults.buttonColors(containerColor = if (micOn) Mint else Purple), shape = CircleShape, modifier = Modifier.size(76.dp)) {
            Icon(if (micOn) Icons.Default.Mic else Icons.Default.MicOff, contentDescription = "Toggle microphone", tint = Navy, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(10.dp)); Text(if (micOn) "মাইক বন্ধ করো" else "মাইক চালু করো", color = Color.White, fontSize = 12.sp)
        Spacer(Modifier.height(30.dp))
        OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF7777))) { Text("Leave room") }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
fun Avatar(initial: String, name: String, speaking: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(68.dp).background(if (speaking) Purple else Color(0xFF30365D), CircleShape), contentAlignment = Alignment.Center) { Text(initial, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(7.dp)); Text(name, color = Color.White, fontSize = 12.sp)
        if (speaking) Text("Host", color = Mint, fontSize = 10.sp)
    }
}

@Composable
fun CreateRoomDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("নতুন ভয়েস রুম", color = Color.White) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("রুমের নাম") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name.trim()) }) { Text("তৈরি করো") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}

@Composable
fun SimpleTab(title: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("$title\nশীঘ্রই আসছে", color = Color.White, fontSize = 22.sp, lineHeight = 32.sp) }
}
